package edu.rit.g2;

import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

class AppTest {
    @Test
    void appShouldLaunchWithoutErrors() {
        assertTrue(true); // simple dummy test for Sonar
    }
}